const express = require('express');

const getCSRFToken = (t = getCookie(qqcookie, "p_skey") || getCookie(qqcookie, "skey") || getCookie(qqcookie, "access_token")) => {
    if (t === null) return null;
    let hash = 5381;
    t.split("").forEach((char) => {
        hash += (hash << 5) + char.charCodeAt(0);
    });
    return hash & 0x7FFFFFFF;
};

const getCookie = (cookie, name) => {
    const value = cookie.split(name + '=')[1];
    return value ? decodeURIComponent(value.split(';')[0]) : null;
};

const appid = "1104466820"
//这里输入自己在https://youxi.gamecenter.qq.com/ 的cookie
const qqcookie = ''
const mytoken = getCSRFToken()
//这里输入自己在https://h5.nes.smoba.qq.com/pvpesport.web.user/#/ 的cookie 必须通过查看网络请求获取 document.cookie获取无效 部分cookie http only
const smoba_cookie = ''
const apptoken = getCookie(smoba_cookie, 'tip_token')

const router = express.Router();

const https = require('https');
// 定义一个异步函数来发送 HTTPS POST 请求并返回结果
async function send_HttpsPostRequest(url, postData, headers = {}) {
    return new Promise((resolve, reject) => {
        // 解析URL获取主机名、端口和路径等信息
        const parsedUrl = new URL(url);

        // 构造请求选项
        const options = {
            hostname: parsedUrl.hostname,
            port: parsedUrl.port || 443,
            path: parsedUrl.pathname + (parsedUrl.search || ''),
            method: 'POST',
            headers: Object.assign({
                'Content-Type': 'application/json', // 根据实际情况调整内容类型
                'Content-Length': Buffer.byteLength(postData),
            }, headers),
        };

        // 创建请求对象
        const req = https.request(options, (res) => {
            let data = '';

            res.on('data', (chunk) => {
                data += chunk;
            });

            res.on('end', () => {
                if (res.statusCode >= 200 && res.statusCode < 300) {
                    try {
                        resolve(JSON.parse(data)); // 如果响应是 JSON 格式，则解析为对象
                    } catch (error) {
                        resolve(data); // 否则直接返回原始数据
                    }
                } else {
                    reject(new Error(`HTTP ${res.statusCode}: ${data}`));
                }
            });
        });

        req.on('error', (error) => {
            reject(error);
        });

        // 写入请求主体（仅适用于POST等有主体的请求）
        req.write(postData);
        req.end();
    });
}

async function getroom_data(appid, teambusid, teamid) {
    //必须要手动将原来的\转义为\\ 否则\会自动被抹除
    const postData = '{"list":[{"options":{"serializationType":2},"rawData":"{\\"req\\":{\\"tt\\":1,\\"sAppid\\":\\"' + appid + '\\",\\"sTeamId\\":\\"' + teamid + '\\",\\"sTeamBusId\\":\\"' + teambusid + '\\"}}","msg":{"clientRPCName":"/v1/24"}}]}'
    const url = "https://trpc.gamecenter.qq.com/?g_tk=" + mytoken
    const oriurl = "https://youxi.gamecenter.qq.com"
    const headers = {
        'Cookie': qqcookie,
        'Origin': oriurl,
        'Referer': oriurl,
    }

    const result = await send_HttpsPostRequest(url, postData, headers)
    const data = JSON.parse(result.list[0].rawData).rsp
    return {
        sBattleName: data.sBattleName,
        sModeName: data.sModeName,
        sRealTeamBusId: data.sRealTeamBusId,
        sRealTeamId: data.sRealTeamId,
        sSegment: data.sSegment,
        sTeamLeaderRoleId: data.sTeamLeaderRoleId,
        MapID: data.MapID,
        iTeamState: data.iTeamState,
        iTeamType: data.iTeamType
    };
}

async function getroom_data_smoba(roomid) {
    const postData = '{"child_id":' + roomid + '}'

    const url = "https://api.nes.smoba.qq.com/pvpesport.sgamenes.commcgi.commcgi/QueryRoomInfo?g_app_tk=" + apptoken
    const oriurl = "https://h5.nes.smoba.qq.com/"
    const headers = {
        'Cookie': smoba_cookie,
        'Origin': oriurl,
        'Referer': oriurl,
    }

    try {
        const result = await send_HttpsPostRequest(url, postData, headers)
        const data = result.room_info
        return {
            battle_id: data.battle_id,
            gamedata: data.gamedata,
            schid: data.schid,
            sch_state: data.sch_state,
            battle_state: data.battle_state,
            child_name: data.child_name,
        };
    } catch (error) {
        console.error('Error fetching data:', error.message);
        throw error;
    }

}

async function getgamedata_smoba(roomid) {
    const postData = '{"child_id":' + roomid + ',"without_rule":true}'

    const url = "https://api.nes.smoba.qq.com/pvpesport.sgamenes.nesholder.nesholder/QueryPubGameInfo?g_app_tk=" + apptoken
    const oriurl = "https://h5.nes.smoba.qq.com"
    const headers = {
        'Cookie': smoba_cookie,
        'Origin': oriurl,
        'Referer': oriurl,
    }

    try {
        const result = await send_HttpsPostRequest(url, postData, headers)
        const data = result.game_info.match_rule_cfg
        return {
            comm_fields: data.comm_fields,
            battle_custom_params: data.battle_custom_params
        };
    } catch (error) {
        console.error('Error fetching data:', error.message);
        throw error;
    }

}

function extractAndMerge(originalJson) {

    function extractAndMergeJsonList(jsonList) {
        const extractedJson = {};

        jsonList.forEach((originalJson) => {
            let id_str = originalJson.ename.toString() + "|";
            let name = originalJson.cname;
            let type2_str = originalJson.hero_type2 || "";
            let type_str = originalJson.hero_type.toString() + (type2_str ? "|" : "");

            extractedJson[name] = id_str + type_str + type2_str;
        });

        return extractedJson;
    }


    const extractedJson = extractAndMergeJsonList(originalJson)

    return extractedJson
}

async function getheros() {
    const url = "https://pvp.qq.com/web201605/js/herolist.json";
    const oriurl = "https://pvp.qq.com";

    const headers = new Headers({
        'Origin': oriurl,
        'Referer': oriurl,
    });

    try {
        const response = await fetch(url, {
            method: 'GET',
            headers: headers
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        const extractedData = extractAndMerge(data);

        return extractedData;
    } catch (error) {
        console.error('Fetch error:', error);
    }
}

router.get('/getheros', async function (req, res) {
    try {
        const mydata = await getheros();
        console.log(mydata)
        res.json(mydata);
    } catch (error) {
        console.error('获取数据失败:', error.message);
        res.status(500).json({ error: '服务器错误' });
    }
});

router.get('/getroom', async function (req, res) {
    try {
        // 获取查询参数
        const teambusid = req.query.teambusid;

        // 校验参数是否存在
        if (!teambusid) {
            res.status(400).send("teambusid is required");
            return;
        }

        // 获取查询参数
        const teamid = req.query.teamid;

        // 校验参数是否存在
        if (!teamid) {
            res.status(400).send("teamid is required");
            return;
        }

        //appid填写正式服即可
        const mydata = await getroom_data(appid, teambusid, teamid);
        console.log(mydata)
        res.json(mydata);
    } catch (error) {
        console.error('获取数据失败:', error.message);
        res.status(500).json({ error: '服务器错误' });
    }
});

router.get('/getroom_smoba', async function (req, res) {
    try {
        res.json({ status: "500", error: '本功能已被官方和谐' });
    } catch (error) {
        console.error('获取数据失败:', error.message);
        res.status(500).json({ error: '服务器错误' });
    }
});

/*
router.get('/getroom_smoba', async function (req, res) {
    try {
        // 获取查询参数
        const myid = req.query.id;

        // 校验参数是否存在
        if (!myid) {
            res.status(400).send("ID is required");
            return;
        }

        var mydata = await getroom_data_smoba(myid);
        if (mydata.gamedata) {
            const extradata = await getgamedata_smoba(myid)
            mydata = Object.assign({}, mydata, extradata);
        }
        res.json(mydata);
    } catch (error) {
        console.error('获取数据失败:', error.message);
        res.status(500).json({ error: '服务器错误' });
    }
});
*/

const app = express();
app.use(router)

const serverless = require('serverless-http');
module.exports.handler = serverless(app);

app.all('*', function (req, res, next) {
    res.header('Content-Type', 'application/json;charset=utf-8');
    next();
});


// 本地运行
// 监听端口为3000
const server = app.listen(3000, function () {
    const port = server.address().port;
    console.info('http://localhost:' + port)
});
